# Logisticregression-using-numpy
Logistic Regression using Numpy 
The LR models acts as a binary classifier to classify an image as a cat or non-cat using sigmoid activation function.





